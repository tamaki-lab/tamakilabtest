# pipインストールするパッケージ作成用テストリポジトリ


参考：

- https://packaging.python.org/en/latest/
- https://packaging.python.org/ja/latest/
